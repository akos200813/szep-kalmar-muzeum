import { openModal } from './modal.js';

export function renderCards(data, grid, countEl, noRes) {
  grid.innerHTML = '';

  data.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';

    card.innerHTML = `
      <div class="card-img-wrap">
        <img class="card-img" src="${item.img}" alt="${item.title}">
      </div>
      <div class="card-num">${String(item.n).padStart(2, '0')}</div>
      ${item.era ? `<div class="card-era">${item.era}</div>` : ''}
      <div class="card-title">
        ${item.highlight ? `<span class="hl">${item.title}</span>` : item.title}
      </div>
      ${item.maker ? `<div class="card-maker">${item.maker}</div>` : ''}
      ${item.sub ? `<div class="card-sub">${item.sub}</div>` : ''}
    `;

    card.addEventListener('click', () => openModal(item));

    grid.appendChild(card);
  });

  countEl.textContent = `${data.length} tárgy`;
  noRes.classList.toggle('show', data.length === 0);
}
