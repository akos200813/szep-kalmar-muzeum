import { renderCards } from './render.js';
import { filterItems } from './filter.js';

const grid     = document.querySelector('#grid');
const searchEl = document.querySelector('#search');
const noRes    = document.querySelector('#noRes');
const countEl  = document.querySelector('#count');

let items = [];

// Adatok betöltése JSON-ből
fetch('./assets/data/items.json')
  .then(res => res.json())
  .then(data => {
    items = data;
    renderCards(items, grid, countEl, noRes);
  })
  .catch(err => {
    console.error('Nem sikerült betölteni az adatokat:', err);
  });

function update() {
  const query = searchEl.value.trim().toLowerCase();
  const activeBtn = document.querySelector('.filter-btn.active');
  const cat = activeBtn ? activeBtn.dataset.cat : 'all';

  const result = filterItems(items, query, cat);
  renderCards(result, grid, countEl, noRes);
}

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    update();
  });
});

searchEl.addEventListener('input', update);
