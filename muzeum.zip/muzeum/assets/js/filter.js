export function filterItems(items, query, cat) {
  return items.filter(item => {
    const text = [
      item.title || '',
      item.maker || '',
      item.era || '',
      item.sub || ''
    ]
      .join(' ')
      .toLowerCase();

    const matchQuery = !query || text.includes(query);
    const matchCat   = cat === 'all' || item.cat === cat;

    return matchQuery && matchCat;
  });
}
