export function openModal(item) {
  const modal = document.getElementById('modal');
  const img   = document.getElementById('modal-img');

  document.getElementById('modal-title').textContent = item.title;
  document.getElementById('modal-maker').textContent = item.maker || '';
  document.getElementById('modal-era').textContent   = item.era || '';
  document.getElementById('modal-sub').textContent   = item.sub || '';

  img.src = item.img;

  modal.classList.add('show');
}

export function closeModal() {
  document.getElementById('modal').classList.remove('show');
}

document.addEventListener('click', e => {
  if (e.target.id === 'modal') closeModal();
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});
